# TinyCalculator

A Tiny calculator made with Java and JSF(Java Server Faces), allowing one do the most basic of calculations; add, subtract, multiply, and divide.
