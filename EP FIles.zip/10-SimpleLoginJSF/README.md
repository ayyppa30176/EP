![alt text](https://github.com/Jhooomn/SimpleLoginJSFTest/blob/master/web/img/capture.PNG)
