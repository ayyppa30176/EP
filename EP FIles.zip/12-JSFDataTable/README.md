Simple Data Table - JSF 2 - NetBeans IDE
